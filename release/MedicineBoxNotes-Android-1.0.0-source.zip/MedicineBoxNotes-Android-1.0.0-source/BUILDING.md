# MedicineBoxNotes Android 1.0.0 source package

This archive contains the publishable Android source tree. It intentionally
excludes local SDK paths, signing keys, built APK/AAB files, Gradle caches,
device recordings, demonstration media, and the optional Gemma model binary.

## Requirements

- Android Studio with JDK 17
- Android SDK Platform 36
- Android SDK Build Tools 36.0.0
- An arm64 Android device for on-device model testing

Android Studio normally creates `local.properties` automatically. For a
command-line build, create it locally with your Android SDK path:

```properties
sdk.dir=/absolute/path/to/your/android-sdk
```

## Build

```sh
./gradlew :app:assembleDebug
./gradlew :app:assembleRelease
./gradlew :app:bundleRelease
```

The release build is intentionally not tied to a repository keystore. Use
Android Studio's **Build > Generate Signed App Bundle or APK** flow, or add a
private release signing configuration outside source control. Never commit a
release keystore or its passwords.

## Optional Gemma model

The app remains usable without the model. Model metadata and the official
Hugging Face download location are in
`models/gemma-4-e2b/model-manifest.json`. The multi-gigabyte `.litertlm`
binary is not bundled in this source archive.

## Included modules

- `app`
- `core-model`
- `core-database`
- `core-designsystem`
- `core-ai`

Application icon and splash resources used by the build are retained under
`doc/images/MedicineBoxNotes/Assets.xcassets`.
